'''
工具包汇总调用
'''
from src.utils.Draw_Utils import *
import src.utils.GA_Utils as GA_Utils
import src.utils.DE_Utils as DE_Utils
from src.utils.Mean_Vector_Util import *
from src.utils.MOEAD_Utils import *
